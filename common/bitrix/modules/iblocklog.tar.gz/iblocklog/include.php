<?php
Bitrix\Main\Loader::registerAutoloadClasses(
    "iblocklog",
    array(
        "Iblocklog\\D7\\Handlers" => "lib/Handlers.php",
        "Iblocklog\\D7\\LogTable" => "lib/LogTable.php",
    )
);



