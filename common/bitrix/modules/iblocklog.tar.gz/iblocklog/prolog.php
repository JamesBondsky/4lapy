<?php
IncludeModuleLangFile(__FILE__);


?>