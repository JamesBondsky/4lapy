<?php
$MESS["PERFMON_HIT_FIND"] = "Найти";
?>