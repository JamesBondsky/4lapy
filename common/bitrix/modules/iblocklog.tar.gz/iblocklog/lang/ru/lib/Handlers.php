<?php
$MESS ['IBLOCKLOG_IBLOCK_TYPE_NAME'] = "Перевод для обработчиков";

?>