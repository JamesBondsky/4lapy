<?php
$MESS ['IBLOCKLOG_ID_FIELD'] = "ID ключ";
$MESS ['IBLOCKLOG_MOD_USER_ID'] = "ID Пользователя";
$MESS ['IBLOCKLOG_ELEMENT_ID'] = "ID Элемента";
$MESS ['IBLOCKLOG_ENTITY_NAME_FIELD'] = "Имя пользователя";
$MESS ['IBLOCKLOG_DATE_UPDATE'] = "Обновлённая дата";
$MESS ['IBLOCKLOG_IBLOCK_ID'] = "ID инфоблока";
?>