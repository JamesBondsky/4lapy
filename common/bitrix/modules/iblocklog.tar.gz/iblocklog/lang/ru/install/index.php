<?php
$MESS ['IBLOCKLOG_IBLOCK_TYPE_NAME'] = "Логирование инфоблоков";
$MESS ['IBLOCKLOG_IBLOCK_ARTICLES_NAME'] = "Логирование инфоблоков";
$MESS ['IBLOCKLOG_IBLOCK_ARTICLES_PROP_SBS_ID'] = "Логирование инфоблоков";
$MESS ['IBLOCKLOG_IBLOCK_PROP_PUBLISHED_ON_SBS'] = "Логирование инфоблоков";
$MESS ['IBLOCKLOG_IBLOCK_PROP_VIEW_COUNT'] = "Логирование инфоблоков";
$MESS ['IBLOCKLOG_IBLOCK_PROP_LECTURE_THEME_SBS_ID'] = "Логирование инфоблоков";
$MESS ['IBLOCKLOG_IBLOCK_TYPE_NOT_INSTALLED'] = "Логирование инфоблоков";
$MESS ['IBLOCKLOG_IBLOCK_VIDEO_PROP_SBS_ID'] = "Логирование инфоблоков";
$MESS ['IBLOCKLOG_IBLOCK_VIDEO_PROGRAMM_LAND'] = "Логирование инфоблоков";
$MESS ['IBLOCKLOG_IBLOCK_TOPIC_PROP_SBS_ID'] = "Логирование инфоблоков";
$MESS ['IBLOCKLOG_IBLOCK_SPEAKERS_PROP_SBS_ID'] = "Логирование инфоблоков";
$MESS ['IBLOCKLOG_IBLOCK_SPEAKERS_PROP_NAME'] = "Логирование инфоблоков";
$MESS ['IBLOCKLOG_IBLOCK_SPEAKERS_PROP_LAST_NAME'] = "Логирование инфоблоков";
$MESS ['IBLOCKLOG_IBLOCK_SPEAKERS_PROP_AVATAR'] ="Логирование инфоблоков";
$MESS ['IBLOCKLOG_IBLOCK_SPEAKERS_PROP_BIG_AVATAR'] = "Логирование инфоблоков";
$MESS ['IBLOCKLOG_IBLOCK_PROP_LECTURE_THEME'] = "Логирование инфоблоков";
$MESS ['IBLOCKLOG_IBLOCK_SPEAKERS_PROP_ABOUT'] = "Логирование инфоблоков";
$MESS ['IBLOCKLOG_IBLOCK_SPEAKERS_PROP_ABOUT_TITLE'] = "Логирование инфоблоков";
$MESS ['IBLOCKLOG_IBLOCK_SPEAKERS_PROP_FURTHER'] = "Логирование инфоблоков";
?>