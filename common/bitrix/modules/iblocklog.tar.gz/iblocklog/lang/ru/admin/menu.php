<?php
$MESS["IBLOCKLOG_MNU_SECT"] = "Логирование инфоблоков";
$MESS["IBLOCKLOG_MNU_SECT_TITLE"] = "Логирование инфоблоков";
$MESS["IBLOCKLOG_SYNC_LOG"] = "Лог инфоблоков";
$MESS["IBLOCKLOG_MANUAL_SYNC"] = "Лог инфоблоков";
?>