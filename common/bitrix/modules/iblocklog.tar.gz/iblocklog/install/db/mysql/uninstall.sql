DROP TABLE if exists c_iblock_element_log;


