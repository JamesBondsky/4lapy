<?php
$arModuleVersion = array(
    "VERSION" => "1.0.0",
    "VERSION_DATE" => "2017-01-25 15:00:00"
);