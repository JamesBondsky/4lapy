<?if(!check_bitrix_sessid()) return;?>
<?php
echo CAdminMessage::ShowNote("Модуль успешно удален из системы");
?>