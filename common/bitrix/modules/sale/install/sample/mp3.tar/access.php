<?
$PERM["index.php"]["2"]="R";
$PERM["index.php"]["*"]="R";
$PERM["original"]["2"]="R";
$PERM["original"]["*"]="R";
$PERM["buy_money.php"]["2"]="R";
$PERM["buy_money.php"]["*"]="R";
?>