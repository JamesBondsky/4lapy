<?
// Please type the correct path to the init_vars.php file
include_once($_SERVER["DOCUMENT_ROOT"]."/mp3/init_vars.php");
?>